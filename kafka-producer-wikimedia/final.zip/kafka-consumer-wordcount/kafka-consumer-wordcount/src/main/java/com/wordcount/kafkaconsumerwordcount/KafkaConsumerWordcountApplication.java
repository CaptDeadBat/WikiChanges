package com.wordcount.kafkaconsumerwordcount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaConsumerWordcountApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaConsumerWordcountApplication.class, args);
	}

}
