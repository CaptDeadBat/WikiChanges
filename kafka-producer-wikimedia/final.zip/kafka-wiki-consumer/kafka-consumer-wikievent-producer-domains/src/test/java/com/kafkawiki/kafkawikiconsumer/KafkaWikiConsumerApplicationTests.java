package com.kafkawiki.kafkawikiconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaWikiConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
