package com.kafkawiki.kafkawikiconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaWikiConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaWikiConsumerApplication.class, args);
	}

}
